-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10b303.p.ssafy.io    Database: member
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cropfavorites`
--

DROP TABLE IF EXISTS `cropfavorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cropfavorites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_liked` tinyint(1) NOT NULL,
  `user_id` bigint NOT NULL,
  `crop_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `crop_id` (`crop_id`),
  CONSTRAINT `cropfavorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `cropfavorites_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `crop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cropfavorites`
--

LOCK TABLES `cropfavorites` WRITE;
/*!40000 ALTER TABLE `cropfavorites` DISABLE KEYS */;
INSERT INTO `cropfavorites` VALUES (1,1,1,11),(2,1,1,21),(3,0,1,88),(4,1,1,45),(5,1,1,42),(6,1,1,83),(7,0,1,3),(8,1,1,1),(9,0,1,6),(10,0,10,6),(11,0,10,1),(12,0,10,2),(13,0,10,3),(14,0,10,4),(15,0,10,15),(16,1,1,5),(17,1,1,15),(18,1,1,2),(19,0,11,2),(20,0,1,9),(21,0,11,5),(22,0,11,4),(23,1,10,10),(24,1,10,19),(25,1,10,29),(26,1,10,5),(27,1,11,1),(28,0,11,10),(29,1,10,24),(30,1,11,18),(31,0,11,15),(32,1,11,32),(33,1,11,7),(34,0,11,33),(35,1,1,87),(37,1,4,20),(38,1,4,15),(39,1,4,81),(40,1,4,31);
/*!40000 ALTER TABLE `cropfavorites` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 23:04:57
