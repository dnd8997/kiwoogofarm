-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10b303.p.ssafy.io    Database: member
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `role` enum('GUEST','USER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_type` enum('KAKAO','NAVER','GOOGLE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'jungyoanwoo@naver.com','d741b5cc-2a4b-451d-9f4b-462d2bf70cad','정연우','http://k.kakaocdn.net/dn/uSPQg/btr3aKIsSHo/VOfsoyS8zxOTlMweCIkPuk/img_110x110.jpg',0,'USER','KAKAO','3390072918',NULL),(4,'wldnjs9397@daum.net','9a050d81-831b-4ed4-bb12-d0c993a92eaa','한지원','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R110x110',0,'USER','KAKAO','3397822194',NULL),(5,'gk','kk','sooji','dslkdf',11,'USER','KAKAO','social_id','refresh'),(10,'dnd8997@naver.com','045c14fe-6552-4861-b964-b5562583f582','윤건웅','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R110x110',0,'USER','KAKAO','3395125315',NULL),(11,'gkdrhd6788@naver.com','c79bf509-84c7-486f-91bb-53eaab1e7412','권수지','http://k.kakaocdn.net/dn/Kzs7O/btruwIJ5jou/DksK9OMkSCRXahOkScmqi0/img_110x110.jpg',0,'USER','KAKAO','3409857560',NULL),(12,'chosju66@gmail.com','0afefd0e-3200-402b-b377-a912e4aa93d6','조성주','http://k.kakaocdn.net/dn/jFXjE/btsGkDwkdwg/vMqPFYXGM7iRM4VKAGlrlK/img_110x110.jpg',0,'USER','KAKAO','3390078361',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 23:04:51
